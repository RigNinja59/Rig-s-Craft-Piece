// Made with Blockbench 4.10.4
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports

public static class ModelFalcon extends EntityModel<Entity> {
	private final ModelRenderer body;
	private final ModelRenderer head;
	private final ModelRenderer leftwing;
	private final ModelRenderer rightwing;
	private final ModelRenderer rightclaw;
	private final ModelRenderer leftclaw;

	public ModelFalcon() {
		textureWidth = 64;
		textureHeight = 64;

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, 19.0F, -2.0F);
		body.setTextureOffset(0, 0).addBox(-2.0F, -1.0F, 0.0F, 4.0F, 2.0F, 8.0F, 0.0F, false);
		body.setTextureOffset(0, 14).addBox(-2.0F, -1.0F, 8.0F, 4.0F, 0.0F, 6.0F, 0.0F, false);

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, 19.0F, -2.0F);
		head.setTextureOffset(14, 14).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 2.0F, 4.0F, 0.0F, false);
		head.setTextureOffset(0, 0).addBox(-1.0F, 0.0F, -5.0F, 2.0F, 1.0F, 1.0F, 0.0F, false);

		leftwing = new ModelRenderer(this);
		leftwing.setRotationPoint(2.0F, 18.0F, 0.0F);
		leftwing.setTextureOffset(12, 0).addBox(0.0F, 0.0F, -2.0F, 8.0F, 0.0F, 4.0F, 0.0F, false);

		rightwing = new ModelRenderer(this);
		rightwing.setRotationPoint(-2.0F, 18.0F, 0.0F);
		rightwing.setTextureOffset(0, 10).addBox(-8.0F, 0.0F, -2.0F, 8.0F, 0.0F, 4.0F, 0.0F, false);

		rightclaw = new ModelRenderer(this);
		rightclaw.setRotationPoint(-1.5F, 20.0F, 2.5F);
		rightclaw.setTextureOffset(13, 4).addBox(-1.5F, 2.0F, -1.5F, 3.0F, 0.0F, 3.0F, 0.0F, false);
		rightclaw.setTextureOffset(4, 2).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 2.0F, 1.0F, 0.0F, false);

		leftclaw = new ModelRenderer(this);
		leftclaw.setRotationPoint(3.0F, 22.0F, 2.0F);
		leftclaw.setTextureOffset(17, 10).addBox(-3.0F, 0.0F, -1.0F, 3.0F, 0.0F, 3.0F, 0.0F, false);
		leftclaw.setTextureOffset(0, 2).addBox(-2.0F, -2.0F, 0.0F, 1.0F, 2.0F, 1.0F, 0.0F, false);
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red,
			float green, float blue, float alpha) {
		body.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		head.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		leftwing.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		rightwing.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		rightclaw.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		leftclaw.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		this.head.rotateAngleY = f3 / (180F / (float) Math.PI);
		this.head.rotateAngleX = f4 / (180F / (float) Math.PI);
	}
}