package net.mcreator.craftpiece.procedures;

import net.minecraft.util.math.MathHelper;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.craftpiece.potion.SlipperyPotionEffect;
import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Random;
import java.util.Map;

public class SlipperyActiveTickConditionProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency entity for procedure SlipperyActiveTickCondition!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.setMotion((entity.getMotion().getX() * MathHelper.nextInt(new Random(), 0, 2)), (-1),
				(entity.getMotion().getZ() * MathHelper.nextInt(new Random(), 0, 2)));
		entity.fallDistance = (float) (0);
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.SPEED, (int) 1, (int) 1, (false), (false)));
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, (int) 1, (int) 3, (false), (false)));
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.WEAKNESS, (int) 1, (int) 3, (false), (false)));
		if (entity.isInWaterRainOrBubbleColumn()) {
			if (entity instanceof LivingEntity) {
				((LivingEntity) entity).removePotionEffect(SlipperyPotionEffect.potion);
			}
		}
	}
}
