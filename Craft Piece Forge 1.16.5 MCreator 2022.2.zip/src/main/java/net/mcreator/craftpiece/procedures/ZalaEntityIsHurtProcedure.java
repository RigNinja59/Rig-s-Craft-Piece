package net.mcreator.craftpiece.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.Entity;

import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Map;

public class ZalaEntityIsHurtProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency sourceentity for procedure ZalaEntityIsHurt!");
			return;
		}
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		sourceentity.attackEntityFrom(DamageSource.GENERIC, (float) 4);
	}
}
