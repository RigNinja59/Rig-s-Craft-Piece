package net.mcreator.craftpiece.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.ExplosionEvent;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.Explosion;

import net.mcreator.craftpiece.CraftPieceModVariables;
import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Map;
import java.util.HashMap;

public class DetectExplosionProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onExplode(ExplosionEvent.Detonate event) {
			World world = event.getWorld();
			Explosion explosion = event.getExplosion();
			double i = explosion.getPosition().x;
			double j = explosion.getPosition().y;
			double k = explosion.getPosition().z;
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", i);
			dependencies.put("y", j);
			dependencies.put("z", k);
			dependencies.put("world", world);
			dependencies.put("event", event);
			executeProcedure(dependencies);
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency world for procedure DetectExplosion!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		CraftPieceModVariables.MapVariables.get(world).explosionFORBOMU = 1;
		CraftPieceModVariables.MapVariables.get(world).syncData(world);
	}
}
