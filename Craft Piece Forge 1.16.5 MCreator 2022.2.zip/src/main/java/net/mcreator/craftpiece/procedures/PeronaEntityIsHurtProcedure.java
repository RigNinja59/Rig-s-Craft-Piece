package net.mcreator.craftpiece.procedures;

import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Map;

public class PeronaEntityIsHurtProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency entity for procedure PeronaEntityIsHurt!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency sourceentity for procedure PeronaEntityIsHurt!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.GLOWING, (int) 200, (int) 1));
		sourceentity.setMotion((sourceentity.getMotion().getX() * (-2)), (sourceentity.getMotion().getY() * (-2)),
				(sourceentity.getMotion().getZ() * (-2)));
	}
}
