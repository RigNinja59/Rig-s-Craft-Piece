package net.mcreator.craftpiece.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Map;

public class AlvidaPlayerCollidesWithThisEntityProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency entity for procedure AlvidaPlayerCollidesWithThisEntity!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.setMotion((2 * entity.getMotion().getX()), (entity.getMotion().getY()), (2 * entity.getMotion().getZ()));
	}
}
