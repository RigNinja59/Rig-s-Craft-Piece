package net.mcreator.craftpiece.procedures;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.IWorld;

import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Map;

public class TokiTokiClockPlayerFinishesUsingItemProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency world for procedure TokiTokiClockPlayerFinishesUsingItem!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		if (world instanceof ServerWorld)
			((ServerWorld) world).setDayTime((int) (world.getWorldInfo().getDayTime() + 10000));
		world.getWorldInfo().setRaining((!world.getWorldInfo().isRaining()));
	}
}
