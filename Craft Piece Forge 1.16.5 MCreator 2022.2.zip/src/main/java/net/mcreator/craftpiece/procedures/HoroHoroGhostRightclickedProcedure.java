package net.mcreator.craftpiece.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.IWorld;
import net.minecraft.world.GameType;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.craftpiece.CraftPieceModVariables;
import net.mcreator.craftpiece.CraftPieceMod;

import java.util.Map;
import java.util.Collections;

public class HoroHoroGhostRightclickedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency world for procedure HoroHoroGhostRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CraftPieceMod.LOGGER.warn("Failed to load dependency entity for procedure HoroHoroGhostRightclicked!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		Entity entity = (Entity) dependencies.get("entity");
		CraftPieceModVariables.MapVariables.get(world).xFORHORO = (entity.getPosX());
		CraftPieceModVariables.MapVariables.get(world).syncData(world);
		CraftPieceModVariables.MapVariables.get(world).yFORHORO = (entity.getPosY());
		CraftPieceModVariables.MapVariables.get(world).syncData(world);
		CraftPieceModVariables.MapVariables.get(world).zFORHORO = (entity.getPosZ());
		CraftPieceModVariables.MapVariables.get(world).syncData(world);
		if (entity instanceof PlayerEntity)
			((PlayerEntity) entity).setGameType(GameType.SPECTATOR);
		new Object() {
			private int ticks = 0;
			private float waitTicks;
			private IWorld world;

			public void start(IWorld world, int waitTicks) {
				this.waitTicks = waitTicks;
				MinecraftForge.EVENT_BUS.register(this);
				this.world = world;
			}

			@SubscribeEvent
			public void tick(TickEvent.ServerTickEvent event) {
				if (event.phase == TickEvent.Phase.END) {
					this.ticks += 1;
					if (this.ticks >= this.waitTicks)
						run();
				}
			}

			private void run() {
				{
					Entity _ent = entity;
					_ent.setPositionAndUpdate(CraftPieceModVariables.MapVariables.get(world).xFORHORO,
							CraftPieceModVariables.MapVariables.get(world).yFORHORO, CraftPieceModVariables.MapVariables.get(world).zFORHORO);
					if (_ent instanceof ServerPlayerEntity) {
						((ServerPlayerEntity) _ent).connection.setPlayerLocation(CraftPieceModVariables.MapVariables.get(world).xFORHORO,
								CraftPieceModVariables.MapVariables.get(world).yFORHORO, CraftPieceModVariables.MapVariables.get(world).zFORHORO,
								_ent.rotationYaw, _ent.rotationPitch, Collections.emptySet());
					}
				}
				if (entity instanceof PlayerEntity)
					((PlayerEntity) entity).setGameType(GameType.SURVIVAL);
				MinecraftForge.EVENT_BUS.unregister(this);
			}
		}.start(world, (int) 600);
	}
}
