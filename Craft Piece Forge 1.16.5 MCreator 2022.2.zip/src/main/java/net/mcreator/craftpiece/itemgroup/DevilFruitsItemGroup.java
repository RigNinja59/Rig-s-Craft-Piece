
package net.mcreator.craftpiece.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.craftpiece.item.GomuGomuNoMiItem;
import net.mcreator.craftpiece.CraftPieceModElements;

@CraftPieceModElements.ModElement.Tag
public class DevilFruitsItemGroup extends CraftPieceModElements.ModElement {
	public DevilFruitsItemGroup(CraftPieceModElements instance) {
		super(instance, 49);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabdevil_fruits") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(GomuGomuNoMiItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
