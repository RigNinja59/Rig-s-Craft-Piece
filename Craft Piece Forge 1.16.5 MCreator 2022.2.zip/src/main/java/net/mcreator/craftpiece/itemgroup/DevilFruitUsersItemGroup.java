
package net.mcreator.craftpiece.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.craftpiece.CraftPieceModElements;

@CraftPieceModElements.ModElement.Tag
public class DevilFruitUsersItemGroup extends CraftPieceModElements.ModElement {
	public DevilFruitUsersItemGroup(CraftPieceModElements instance) {
		super(instance, 62);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabdevil_fruit_users") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(Items.CREEPER_SPAWN_EGG);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
