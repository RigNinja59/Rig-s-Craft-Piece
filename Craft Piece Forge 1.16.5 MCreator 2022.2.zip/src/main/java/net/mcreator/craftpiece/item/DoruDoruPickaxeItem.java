
package net.mcreator.craftpiece.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.craftpiece.itemgroup.DevilFruitsItemGroup;
import net.mcreator.craftpiece.CraftPieceModElements;

import java.util.List;

@CraftPieceModElements.ModElement.Tag
public class DoruDoruPickaxeItem extends CraftPieceModElements.ModElement {
	@ObjectHolder("craft_piece:doru_doru_pickaxe")
	public static final Item block = null;

	public DoruDoruPickaxeItem(CraftPieceModElements instance) {
		super(instance, 93);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 10000;
			}

			public float getEfficiency() {
				return 24f;
			}

			public float getAttackDamage() {
				return 4f;
			}

			public int getHarvestLevel() {
				return 1;
			}

			public int getEnchantability() {
				return 2;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 1, -2.4f, new Item.Properties().group(DevilFruitsItemGroup.tab).isImmuneToFire()) {
			@Override
			public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
				super.addInformation(itemstack, world, list, flag);
				list.add(new StringTextComponent("Mine faster than ever!"));
			}
		}.setRegistryName("doru_doru_pickaxe"));
	}
}
