
package net.mcreator.craftpiece.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.block.BlockState;

import net.mcreator.craftpiece.CraftPieceModElements;

import java.util.List;

@CraftPieceModElements.ModElement.Tag
public class AwaAwaBubbleProjectileItem extends CraftPieceModElements.ModElement {
	@ObjectHolder("craft_piece:awa_awa_bubble_projectile")
	public static final Item block = null;

	public AwaAwaBubbleProjectileItem(CraftPieceModElements instance) {
		super(instance, 120);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(null).maxStackSize(1).rarity(Rarity.EPIC));
			setRegistryName("awa_awa_bubble_projectile");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}

		@Override
		public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
			super.addInformation(itemstack, world, list, flag);
			list.add(new StringTextComponent("How did you get this? This item is only used as the Awa Awa Bubble's projectile texture."));
		}
	}
}
